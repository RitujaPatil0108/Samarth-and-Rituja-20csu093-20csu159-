import 'package:calculator/bmi_Calc.dart';
import 'package:flutter/material.dart';

void main() 
{
  runApp(
    MaterialApp(
      home: simpleCalc(),//YourWidgetName
      debugShowCheckedModeBanner: false,
    ),
  );
}

